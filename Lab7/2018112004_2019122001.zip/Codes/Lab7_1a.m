b = 1;
a = [1 -0.9];
p=0.9;
zplane(b,a);
%Pole at z = 0.9
%Zero at z =0 