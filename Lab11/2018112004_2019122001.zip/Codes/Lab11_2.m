N=71;
wc = 0.4*pi;
tbvals =[0.7 0.3];
transitionband(N,wc,tbvals);