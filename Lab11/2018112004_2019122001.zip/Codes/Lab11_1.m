N=141;
wc = 0.4*pi;
% wc2 = 0.6*pi;
type1_dft(N,wc);
%11.1b) The filter frequency response is similar in shappe to the ideal
%filter response, but there are ripples in the passband and the stopband.
%11.1c)The response becomes closer and closer to that of the ideal LPF as 
%N is increased.